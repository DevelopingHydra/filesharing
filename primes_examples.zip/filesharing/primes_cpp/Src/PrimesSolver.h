#ifndef PRIMESSOLVER_H_
#define PRIMESSOLVER_H_

#include <stdbool.h>
#include "main.h"

#include "DWT_stopwatch.h"

class PrimesSolver {
public:
	PrimesSolver();

	void run_primes();

private:
	DWT_stopwatch stopwatch;

	int nth(int n);
	bool is_prime(int number);
	void print_info(unsigned long cycle_count);
};

#endif /* PRIMESSOLVER_H_ */
