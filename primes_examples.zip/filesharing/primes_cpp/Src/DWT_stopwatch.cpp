#include "stm32f3xx_hal.h"
#include "DWT_stopwatch.h"

DWT_stopwatch::DWT_stopwatch() :
		start_count { 0 } {
	this->init_DWT();
}

void DWT_stopwatch::init_DWT() {
	// disable TRC
	CoreDebug->DEMCR &= ~CoreDebug_DEMCR_TRCENA_Msk;
	// enable TRC
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
	// disable counter
	DWT->CTRL &= ~DWT_CTRL_CYCCNTENA_Msk;
	// enable counter
	DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
	// Reset counter
	DWT->CYCCNT = 0;
}

void DWT_stopwatch::reset_and_start() {
	this->start_count = DWT->CYCCNT;
}

unsigned long DWT_stopwatch::stop() {
	u_int32_t stop_count = DWT->CYCCNT;
	u_int32_t diff = stop_count - this->start_count;
	return (unsigned long) diff;
}
