#include "PrimesSolver.h"

PrimesSolver::PrimesSolver() :
		stopwatch { } {
}

void PrimesSolver::print_info(unsigned long cycle_count) {
	int buffer_len = 50;
	char buffer[buffer_len];

	for (int i = 0; i < buffer_len; i++) {
		buffer[i] = 0;
	}

	int wait_states = FLASH->ACR & 0x7; // get last three bits --> latency
	sprintf(buffer, "WS: %d, Cycles: %lu\n", wait_states,
			(unsigned long) cycle_count);

	int index;
	for (index = 0; index < buffer_len; index++) {
		if (buffer[index] == 0) {
			break; // stop before printing useless characters
		}
		ITM_SendChar(buffer[index]); // use ITM console viewer to see output
	}
}

void PrimesSolver::run_primes() {
	while (true) {

		this->stopwatch.reset_and_start();
		int prime = nth(300);
		unsigned long cycle_count = this->stopwatch.stop();
		this->print_info(cycle_count);

		if (prime == 1987) {
			// green LED on
			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, GPIO_PIN_SET);
		} else {
			// red LED on
			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, GPIO_PIN_SET);
		}
		HAL_Delay(300);
		// both LEDs off
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, GPIO_PIN_RESET);
	}

}

int PrimesSolver::nth(int n) {
	int target_nth = n + 1;

	int current_nth_prime = 1;
	int latest_prime = 1;
	int current_number = 1;

	while (current_nth_prime <= target_nth) {
		if (is_prime(current_number)) {
			latest_prime = current_number;
			current_nth_prime++;
		}
		current_number++;
	}

	return latest_prime;
}

bool PrimesSolver::is_prime(int number) {
	int num = 0;

	for (num = 2; num < number; num++) {
		if (number % num == 0) {
			return false;
		}
	}

	return true;
}
