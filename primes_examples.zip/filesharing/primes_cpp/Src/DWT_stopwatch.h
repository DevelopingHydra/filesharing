#ifndef DWT_STOPWATCH_H_
#define DWT_STOPWATCH_H_

#include <stdbool.h>
#include "main.h"

class DWT_stopwatch {
public:
	DWT_stopwatch();

	void reset_and_start();
	unsigned long stop();

private:
	u_int32_t start_count;

	void init_DWT();
};

#endif /* DWT_STOPWATCH_H_ */
