# setup (windows only)

Install Rust

Install itmdump `cargo install itm --vers 0.3.1`

Install binutils `rustup component add llvm-tools-preview` and `cargo install cargo-binutils --vers 0.1.4`

Download OpenOCD from https://github.com/gnu-mcu-eclipse/openocd/releases

Install the ARM utilities from https://developer.arm.com/tools-and-software/open-source-software/developer-tools/gnu-toolchain/gnu-rm/downloads

Install the ST-Link driver from https://www.st.com/en/development-tools/stsw-link009.html. It also comes with the STM32CubeIDE installation.

Add the compilation target: `rustup target add thumbv7em-none-eabihf`

# run the application

To run it first start the OpenOCD session. The following command works if the OpenOCD files are under C:\
`C:\OpenOCD\0.10.0-12-20190422-2015\bin\openocd.exe -s C:\OpenOCD\0.10.0-12-20190422-2015\scripts\ -f interface/stlink-v2-1.cfg -f target/stm32f3x.cfg`

Then run it with `cargo run`
To run it with release optimizations `cargo run --release`