#include "primes.h"
#include <stdbool.h>
#include "main.h"

#include "stm32f3xx_hal.h"

void print_info(uint32_t cycle_diff) {
	int buffer_len = 50;
	char buffer[buffer_len];

	for (int i = 0; i < buffer_len; i++) {
		buffer[i] = 0;
	}

	int wait_states = FLASH->ACR & 0x7; // get last three bits --> latency
	sprintf(buffer, "WS: %d, Cycles: %lu\n", wait_states,
			(unsigned long) cycle_diff);

	int index;
	for (index = 0; index < buffer_len; index++) {
		if (buffer[index] == 0) {
			break; // stop before printing useless characters
		}
		ITM_SendChar(buffer[index]); // use ITM console viewer to see output
	}
}

void setup_DWT() {
	// disable TRC
	CoreDebug->DEMCR &= ~CoreDebug_DEMCR_TRCENA_Msk;
	// enable TRC
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
	// disable counter
	DWT->CTRL &= ~DWT_CTRL_CYCCNTENA_Msk;
	// enable counter
	DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
	// Reset counter
	DWT->CYCCNT = 0;
}

int nth(int n);
bool is_prime(int number);

void run_primes(void) {
	setup_DWT();

	while (true) {

		uint32_t start_cycles = DWT->CYCCNT;
		int prime = nth(300);
		uint32_t stop_cycles = DWT->CYCCNT;
		uint32_t diff = stop_cycles - start_cycles;
		print_info(diff);

		if (prime == 1987) {
			// green LED on
			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, GPIO_PIN_SET);
		} else {
			// red LED on
			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, GPIO_PIN_SET);
		}
		HAL_Delay(300);
		// both LEDs off
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, GPIO_PIN_RESET);
	}

}

int nth(int n) {
	int target_nth = n + 1;

	int current_nth_prime = 1;
	int latest_prime = 1;
	int current_number = 1;

	while (current_nth_prime <= target_nth) {
		if (is_prime(current_number)) {
			latest_prime = current_number;
			current_nth_prime++;
		}
		current_number++;
	}

	return latest_prime;
}

bool is_prime(int number) {
	int num = 0;

	for (num = 2; num < number; num++) {
		if (number % num == 0) {
			return false;
		}
	}

	return true;
}
