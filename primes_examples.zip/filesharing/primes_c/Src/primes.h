/*
 * primes.h
 *
 *  Created on: 17.05.2019
 *      Author: xeniu
 */

#ifndef PRIMES_H_
#define PRIMES_H_

void run_primes(void);


#endif /* PRIMES_H_ */
