//! Initialization code

#![no_std]

#[allow(unused_extern_crates)] // NOTE(allow) bug rust-lang/rust#53964
extern crate panic_halt; // panic handler

pub use cortex_m_rt::entry;
pub use f3::{
    hal::prelude,
    led::Leds,
    hal::stm32f30x::DWT,
};
pub use cortex_m_semihosting::hprintln;

use f3::hal::{prelude::*, stm32f30x, time::Hertz};
use embedded_hal::blocking::delay::{DelayMs, DelayUs};
use cortex_m::peripheral::{SYST, syst::SystClkSource};

/// Frozen clock frequencies
///
/// The existence of this value indicates that the clock configuration can no longer be changed
#[derive(Clone, Copy)]
pub struct MyClocks {
    sysclk: Hertz,
}

unsafe fn freeze(rcc: &stm32f30x::RCC, flash: &stm32f30x::FLASH) -> MyClocks {
    // Enable HSI
    rcc.cr.modify(|_, w| w.hsion().set_bit());
    while rcc.cr.read().hsirdy().bit_is_clear() {}

    // Select HSI
    rcc.cfgr.modify(|_, w| w.sw().bits(0));
    while rcc.cfgr.read().sw().bits() != 0 {}

    // Enable HSE with bypass, disable PLL
    rcc.cr.modify(|_, w| w
        .hsebyp().set_bit()
        .hseon().set_bit()
        .pllon().clear_bit()
        .csson().clear_bit()
    );
    while rcc.cr.read().hserdy().bit_is_clear() {}

    // Set PLL config
    rcc.cfgr.modify(|_, w| w
        .pllsrc().set_bit()
        .pllmul().bits(7)
    );
    rcc.cfgr2.modify(|_, w| w.prediv().bits(0));

    // Enable PLL
    rcc.cr.modify(|_, w| w.pllon().set_bit());
    while rcc.cr.read().pllrdy().bit_is_clear() {}

    // Set Flash latency
    flash.acr.modify(|_, w| w.latency().bits(2));
    while flash.acr.read().latency().bits() != 2 {}

    // Select PLL
    rcc.cfgr.modify(|_, w| w
        .hpre().bits(0)
        .ppre1().bits(4)
        .ppre2().bits(0)
        .sw().bits(2)
    );
    while rcc.cfgr.read().sw().bits() != 2 {}

    MyClocks {
        sysclk: 72.mhz().into(),
    }
}

pub fn init() -> (Delay, Leds) {
    let mut cp = cortex_m::Peripherals::take().unwrap();
    let dp = stm32f30x::Peripherals::take().unwrap();

    // Enable DWT
    cp.DWT.enable_cycle_counter();

    let clocks = unsafe { freeze(&dp.RCC, &dp.FLASH) };

    let mut rcc = dp.RCC.constrain();

    let delay = Delay::new(cp.SYST, clocks);

    let leds = Leds::new(dp.GPIOE.split(&mut rcc.ahb));

    (delay, leds)
}

pub fn get_flash_ws() -> u8 {
    unsafe {
        let flash = &(*stm32f30x::FLASH::ptr());
        flash.acr.read().latency().bits()
    }
}

    pub fn set_flash_ws(){
        unsafe{
            let flash=&(*stm32f30x::FLASH::ptr());
            flash.acr.write(|w|w.latency().bits(1));
        }
    }

/// System timer (SysTick) as a delay provider
pub struct Delay {
    clocks: MyClocks,
    syst: SYST,
}

impl Delay {
    /// Configures the system timer (SysTick) as a delay provider
    pub fn new(mut syst: SYST, clocks: MyClocks) -> Self {
        syst.set_clock_source(SystClkSource::External);

        Delay { syst, clocks }
    }

    /// Releases the system timer (SysTick) resource
    pub fn free(self) -> SYST {
        self.syst
    }
}

impl DelayUs<u32> for Delay {
    fn delay_us(&mut self, us: u32) {
        let rvr = us * (self.clocks.sysclk.0 / 8_000_000);

        assert!(rvr < (1 << 24));

        self.syst.set_reload(rvr);
        self.syst.clear_current();
        self.syst.enable_counter();

        while !self.syst.has_wrapped() {}

        self.syst.disable_counter();
    }
}

impl DelayMs<u32> for Delay {
    fn delay_ms(&mut self, ms: u32) {
        self.delay_us(ms * 1_000);
    }
}

impl DelayMs<u16> for Delay {
    fn delay_ms(&mut self, ms: u16) {
        self.delay_ms(ms as u32);
    }
}

impl DelayMs<u8> for Delay {
    fn delay_ms(&mut self, ms: u8) {
        self.delay_ms(ms as u32);
    }
}

impl DelayUs<u16> for Delay {
    fn delay_us(&mut self, us: u16) {
        self.delay_us(us as u32)
    }
}

impl DelayUs<u8> for Delay {
    fn delay_us(&mut self, us: u8) {
        self.delay_us(us as u32)
    }
}
