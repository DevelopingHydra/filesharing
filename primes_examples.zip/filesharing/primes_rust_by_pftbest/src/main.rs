#![deny(unsafe_code)]
#![no_main]
#![no_std]

use aux5::{entry, prelude::*, Delay, Leds, hprintln, DWT};

#[entry]
fn main() -> ! {
    let (mut delay, mut leds): (Delay, Leds) = aux5::init(); // from the discovery book examples

    aux5::set_flash_ws();

    loop {
        let start = DWT::get_cycle_count();
        let prime = basic_nth(300);
        let end = DWT::get_cycle_count();

        let diff = end - start;
        let ws = aux5::get_flash_ws();
        hprintln!("WS: {}, Cycles: {}", ws, diff);

        if prime == 1987 {
            leds[6].on();
        } else {
            leds[5].on();
        }

        delay.delay_ms(1000_u32);
        leds[5].off();
        leds[6].off();
    }
}

fn is_prime(number: u32) -> bool {
    !(2..number - 1).any(|curr| number % curr == 0)
}

fn nth(num: u32) -> u32 {
    if num <= 0 {
        return 0;
    }
    (1..).filter(|c| is_prime(*c)).nth(num as usize).unwrap()
}


fn basic_nth(n: u32) -> u32 {
    let target_nth = n + 1;

    let mut current_nth_prime = 1;
    let mut latest_prime = 1;
    let mut current_number = 1;

    while current_nth_prime <= target_nth {
        if basic_is_prime(current_number) {
            latest_prime = current_number;
            current_nth_prime+=1;
        }
        current_number+=1;
    }

    return latest_prime;
}

fn basic_is_prime(number: u32) -> bool {
    for num in 2..number {
        if number % num == 0 {
            return false;
        }
    }

    return true;
}
